var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var urlencodedParser = bodyParser.urlencoded({ extended: false }) 
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
app.get('/index.html', function(req, res) {res.sendFile(__dirname + "/" + "index.html");});
app.post('/user', function(req, res){response = {name : req.body.name,clg_name : req.body.clg_name,year: req.body.year};
console.log(response);
res.end(JSON.stringify(response));});
app.post('/index', urlencodedParser, function(req, res){
    console.log(req.body);res.render('data_use', {data: req.body});});
    var server = app.listen(8888, function(){
         host = server.address().address;
         var port = server.address().port;
    console.log("Listening at http://%s:%s", host, port);});